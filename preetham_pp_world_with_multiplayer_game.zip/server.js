const express=require("express"),http=require("http"),WebSocket=require("ws"),path=require("path");
const app=express(),server=http.createServer(app),wss=new WebSocket.Server({server});
app.use(express.static(path.join(__dirname,"public")));
app.use("/game",express.static(path.join(__dirname,"game")));
const P=new Map(),B=new Map();let pid=1,bid=1,W=2400,H=1600;
const spawn=()=>({x:300+Math.random()*(W-600),y:250+Math.random()*(H-500)});
const send=(s,x)=>s.readyState===1&&s.send(JSON.stringify(x));
wss.on("connection",ws=>{let id=""+pid++,q=spawn();P.set(id,{id,name:"Player "+id,x:q.x,y:q.y,angle:0,hp:100,score:0,color:`hsl(${Math.random()*360},75%,60%)`,keys:{}});
send(ws,{type:"welcome",id});ws.on("message",raw=>{try{let m=JSON.parse(raw),p=P.get(id);if(!p)return;if(m.type==="join")p.name=String(m.name||p.name).slice(0,16);if(m.type==="input"){p.keys=m.keys||{};p.angle=+m.angle||0}if(m.type==="shoot"&&(!p.last||Date.now()-p.last>180)){p.last=Date.now();let b=""+bid++;B.set(b,{x:p.x+Math.cos(p.angle)*24,y:p.y+Math.sin(p.angle)*24,vx:Math.cos(p.angle)*11,vy:Math.sin(p.angle)*11,owner:id,life:90})}if(m.type==="respawn"){q=spawn();p.x=q.x;p.y=q.y;p.hp=100}}catch{}});ws.on("close",()=>P.delete(id))});
setInterval(()=>{for(let p of P.values()){let x=(p.keys.d?1:0)-(p.keys.a?1:0),y=(p.keys.s?1:0)-(p.keys.w?1:0);if(x||y){let l=Math.hypot(x,y);p.x+=x/l*5;p.y+=y/l*5}p.x=Math.max(25,Math.min(W-25,p.x));p.y=Math.max(25,Math.min(H-25,p.y))}
for(let [id,b] of B){b.x+=b.vx;b.y+=b.vy;b.life--;let rm=b.life<=0||b.x<0||b.y<0||b.x>W||b.y>H;if(!rm)for(let p of P.values())if(p.id!==b.owner&&p.hp>0&&Math.hypot(p.x-b.x,p.y-b.y)<22){p.hp-=25;rm=true;if(p.hp<=0)P.get(b.owner).score++;break}if(rm)B.delete(id)}
let s={type:"state",players:[...P.values()].map(({id,name,x,y,angle,hp,score,color})=>({id,name,x,y,angle,hp,score,color})),bullets:[...B.values()].map(({x,y})=>({x,y}))};for(let ws of wss.clients)send(ws,s)},50);
server.listen(process.env.PORT||3000,()=>console.log("Preetham PP World + Battle Arena running"));
